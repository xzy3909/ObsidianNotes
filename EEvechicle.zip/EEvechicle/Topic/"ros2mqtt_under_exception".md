DES:
SUB:
PUB:
	[[StateManager.cpp]]
		pubExceptionStatus()