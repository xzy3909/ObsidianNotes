DES:
SUB:
PUB:
	[[NavNodelet.cpp]]
		nav3DStart()
			global_goal_pub_