DES:
SUB:
	[[StateManager.cpp]]
		stateCheckCallback()
PUB: