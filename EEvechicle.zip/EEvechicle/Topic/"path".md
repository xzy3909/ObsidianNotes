DES:
SUB:
	[[Info2NetNodelet.cpp]]
		callback_local_path()
PUB:
