DES:
CLI:
	[[Net2LocalNodelet.cpp]]
		client_updatetime
SRV: