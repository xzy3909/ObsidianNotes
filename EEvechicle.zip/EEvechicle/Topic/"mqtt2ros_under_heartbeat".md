DES:
SUB:
	[[StateManager.cpp]]
		heartbeatCallback()
PUB:
	