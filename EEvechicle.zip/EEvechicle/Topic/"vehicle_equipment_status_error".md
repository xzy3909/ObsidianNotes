DES:
SUB:
	[[StateManager.cpp]]
		equipmentStatusCallback()
			获取油位水位温度湿度
PUB: