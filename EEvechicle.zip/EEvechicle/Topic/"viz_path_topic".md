DES:
SUB:
	[[Info2NetNodelet.cpp]]
		callback_global_path()
PUB: