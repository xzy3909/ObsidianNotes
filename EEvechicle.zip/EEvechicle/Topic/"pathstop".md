DES:
SUB:
	[[StateManager.cpp]]
		pathstopCallback()
PUB:
	[[TaskManagerNodelet.cpp]]
		pub_pathStop()