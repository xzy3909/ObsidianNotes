DES:
SUB:
	[[Info2NetNodelet.cpp]]
		callback_equipment()
PUB:
