DES:
SUB:
PUB:
	[[TaskManagerNodelet.cpp]]
		pub_under_resume()