DES:
SUB:
	[[ControlNodelet.cpp]]
		motorsCallback()
PUB: