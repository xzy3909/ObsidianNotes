DES:
SUB:
	[[StateManager.cpp]]
		stateChecksCallback()
PUB: