DES:
SUB:
PUB:
	[[Net2LocalNodelet.cpp]]
		pub_manual_cmd_