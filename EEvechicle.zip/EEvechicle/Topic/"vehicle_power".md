DES:
SUB:
	[[Info2NetNodelet.cpp]]
		callback_power()
PUB: