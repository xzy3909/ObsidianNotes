DES:
SUB:
	[[TaskManagerNodelet.cpp]]
		callback_hover()
PUB: