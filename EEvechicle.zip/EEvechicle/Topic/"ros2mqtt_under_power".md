DES:
SUB:
	[[StateManager.cpp]]
		underpowerCallback()
			获取功率？
PUB:
	[[Info2NetNodelet.cpp]]