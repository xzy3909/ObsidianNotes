DES:
SUB:
	[[TaskManagerNodelet.cpp]]
		callback_FollowInfo()
PUB: