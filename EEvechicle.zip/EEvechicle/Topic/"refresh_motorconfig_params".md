DES:
CLI:
	[[Net2LocalNodelet.cpp]]
		client_motorconfig
SRV:
	[[MotorConfigNodelet.cpp---todo]]
		Refresh