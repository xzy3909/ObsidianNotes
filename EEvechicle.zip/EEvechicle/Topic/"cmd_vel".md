DES:
SUB:
	[[ControlNodelet.cpp]]
		cmdVelCallback()
PUB:
