DES:
SUB:
	[[StateManager.cpp]]
		autoCallback()
PUB:
	[[TaskManagerNodelet.cpp]]
	