DES:
	路径生成
Function:
Relation:
	Topic:
	