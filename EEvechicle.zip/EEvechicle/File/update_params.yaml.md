[[TaskManagerNodelet.cpp]] 
```YAML
cores_user: cvdn353
cores_ip: 120.253.239.161
cores_port: 8002
cores_passwd: yd299319
cores_use: true
cores_mountpoint: RTCM33_GRCEJ
battery_type: 1
is_open_hover: false
is_shield_rtk: true
voltage_coefficient: 1
is_shield_scatter: true
is_clear_update_params: false
turn_ref_vel: 0.2
convey_mode: 1
enable_trans: false
is_task_finish_open_hover: false
is_open_avoid: true
start_stir_max_weight: 31
stir: 55
v_boat_min: 0.4
decomposition_type: 0
offset_polygons: false
```