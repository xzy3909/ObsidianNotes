[[TaskManagerNodelet.cpp]]
```JSON
{
   "defaultPlanning" : null,
   "isFeed" : [ 0, 0, 0, 0, 0 ],
   "totalDist" : [ 12.471489816162405 ],
   "totalWeight" : [ 0 ]
}
```