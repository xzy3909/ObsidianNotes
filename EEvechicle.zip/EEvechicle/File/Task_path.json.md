[[TaskManagerNodelet.cpp]]
```JSON
{
   "min_power_for_task" : 10,
   "pathIndex" : 1,
   "paths" : null,
   "size" : 0,
   "task" : [
      {
         "goal_point" : {
            "latitude" : 31.006588902742394,
            "longitude" : 120.62093371694877
         },
         "path_type_id" : 1,
         "paths" : [
            {
               "latitude" : 31.006580147198417,
               "longitude" : 120.62080531513109
            },
            {
               "latitude" : 31.007249143143603,
               "longitude" : 120.62080683929213
            },
            {
               "latitude" : 31.007034340597897,
               "longitude" : 120.62093252699542
            },
            {
               "latitude" : 31.006588902742394,
               "longitude" : 120.62093371694877
            }
         ],
         "ref_point" : {
            "latitude" : 31.006439040314859,
            "longitude" : 120.62022349313021
         },
         "start_point" : {
            "latitude" : 31.006580147198417,
            "longitude" : 120.62080531513109
         },
         "tangkou_id" : 1
      },
      {
         "goal_point" : {
            "latitude" : 31.006457564647686,
            "longitude" : 120.62115927562596
         },
         "path_type_id" : 1,
         "paths" : [
            {
               "latitude" : 31.006447745493578,
               "longitude" : 120.62114445491723
            },
            {
               "latitude" : 31.006596693242418,
               "longitude" : 120.62137123721979
            },
            {
               "latitude" : 31.006596074235055,
               "longitude" : 120.62162627588293
            },
            {
               "latitude" : 31.006315638898933,
               "longitude" : 120.62161426485279
            },
            {
               "latitude" : 31.006321073411844,
               "longitude" : 120.62136872055817
            },
            {
               "latitude" : 31.006457564647686,
               "longitude" : 120.62115927562596
            }
         ],
         "ref_point" : {
            "latitude" : 31.006439040314859,
            "longitude" : 120.62022349313021
         },
         "start_point" : {
            "latitude" : 31.006447745493578,
            "longitude" : 120.62114445491723
         },
         "tangkou_id" : 2
      },
      {
         "goal_point" : {
            "latitude" : 31.005502290145699,
            "longitude" : 120.62120697825775
         },
         "path_type_id" : 1,
         "paths" : [
            {
               "latitude" : 31.006108915239274,
               "longitude" : 120.62120294178781
            },
            {
               "latitude" : 31.006103833932738,
               "longitude" : 120.62178389942909
            },
            {
               "latitude" : 31.005904684915546,
               "longitude" : 120.62178456422821
            },
            {
               "latitude" : 31.005900886613581,
               "longitude" : 120.62120001895177
            },
            {
               "latitude" : 31.005692844768742,
               "longitude" : 120.62122410665842
            },
            {
               "latitude" : 31.005683488598372,
               "longitude" : 120.62177953521628
            },
            {
               "latitude" : 31.005503377311481,
               "longitude" : 120.62177727012686
            },
            {
               "latitude" : 31.005502290145699,
               "longitude" : 120.62120697825775
            }
         ],
         "ref_point" : {
            "latitude" : 31.006439040314859,
            "longitude" : 120.62022349313021
         },
         "start_point" : {
            "latitude" : 31.006108915239274,
            "longitude" : 120.62120294178781
         },
         "tangkou_id" : 3
      }
   ],
   "taskId" : 17466,
   "totalDist" : 0
}
```