控制是现有方案???
	autonomous_exploration_development_environment
	far_planner
	gps_rtk
	liorf_localization
	lio_sam
	liovx_ros_driver2
	mqtt_client
	pointcloud_to_laserscan
	polygon_coverage_plan
	robo_localization
	rosserial
	tare_planner
UDF:
	tele_comm
	vehicle_msgs
	vehicle_nav
![[Screenshot from 2025-08-21 09-55-42.png]]pub_cmd和pub_cmds构造的逻辑?????